# Mansoor Shaik — GitHub Pages Portfolio

A responsive, minimal portfolio built with plain HTML, CSS, and JavaScript. No build tools or dependencies are required.

## Files

- `index.html` — page content and sections
- `styles.css` — layout, colors, responsive styling
- `script.js` — mobile navigation and dynamic footer year
- `resume.pdf` — add your own PDF résumé here before publishing
- `.nojekyll` — tells GitHub Pages not to run Jekyll processing

## Before publishing: personalize these items

1. **Résumé:** add your résumé PDF in this folder and name it `resume.pdf`.
2. **Email:** in `index.html`, replace `YOUR.EMAIL@example.com` in both the `mailto:` link and visible text with the email address you want to publish.
3. **LinkedIn:** replace `https://www.linkedin.com/` and “Add your profile” with your actual LinkedIn URL and profile label, or remove that row.
4. **Projects:** update the three sample project cards with real project names, descriptions, technology tags, and repository/demo links. These are explicitly placeholders.
5. **Skills:** replace “Add language” and “Add tool/platform” with skills you genuinely use.
6. **Profile wording:** edit the About text so it reflects your real experience, interests, and accomplishments.

## Publish with GitHub Pages (browser only)

1. Sign in to GitHub as **SMan786786**.
2. Create a **public** repository named exactly `SMan786786.github.io` (GitHub usernames in the repository name should match the account; if GitHub asks for a lowercase name, use `sman786786.github.io`).
3. Open the new repository and choose **Add file → Upload files**.
4. Upload the contents of this folder, not the enclosing `mansoor-portfolio` folder. Ensure `index.html` is at the repository root.
5. Commit the uploaded files to the `main` branch.
6. Open **Settings → Pages**.
7. Under **Build and deployment**, choose **Deploy from a branch**.
8. Set the branch to **main** and folder to **/(root)**, then click **Save**.
9. Wait a few minutes, then open `https://sman786786.github.io/`. GitHub notes that publishing can take up to about 10 minutes.

Official guide: https://docs.github.com/en/pages/quickstart

## Optional: publish with Git from a terminal

After creating the empty repository on GitHub, run these commands from this folder:

```bash
git init
git add .
git commit -m "Create personal portfolio"
git branch -M main
git remote add origin https://github.com/SMan786786/SMan786786.github.io.git
git push -u origin main
```

Then configure **Settings → Pages** as described above.

## Notes

- GitHub Pages serves public websites. Do not commit passwords, API keys, private documents, or personal information you do not want public.
- This is a static site. The email link opens the visitor's email app; it does not send messages through a backend.
- The Google Fonts import requires internet access; fallback system fonts are defined.
